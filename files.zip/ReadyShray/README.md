# Ready Shray — Android source project

A custom wake-word voice assistant with three features, running fully
offline using **Vosk** — a free, open-source speech engine that needs NO
account, NO signup, and NO API key of any kind.

- **Call a contact, or dial any number** — "Ready Shray, call Mom" or
  "Ready Shray, call 9876543210"
- **Search Google** — "Ready Shray, search best pizza near me"
- **Play music through MX Player** — "Ready Shray, play Kesariya" (finds
  that song on your phone and hands it to MX Player), or just
  "Ready Shray, play music" to open MX Player so you can pick yourself

Calling, playing music, and the wake word/command recognition itself all
work fully offline. Searching Google obviously still needs internet to
load results - that's true of any web search.

## Good news — nothing for you to upload

Earlier versions of these instructions asked you to manually add a Vosk
model file. That file is about 40MB, which is too large for GitHub's
mobile browser upload (25MB limit). Instead, the build workflow now
**downloads the model automatically** on GitHub's servers during the build
(they have full internet access, unlike a browser upload). You don't need
to do anything for this - just upload the project zip as usual.

## Permissions this app needs, and why

- **Microphone** — to listen for the wake phrase and your commands
- **Phone / Call** — to dial contacts or numbers by voice
- **Contacts** — to look up a name you say ("call Mom") to an actual number
- **Music/Audio files** — to find a song by name so it can be handed to
  MX Player
- **Notifications** — to show the "Ready Shray is listening" ongoing notice

## How "call any number" works

If what you say after "call"/"dial" is mostly digits — either spoken as a
full number or spoken digit-by-digit ("nine eight seven six...") — Ready
Shray dials it directly. Otherwise it treats what you said as a contact
name and looks it up.

## An honest heads-up about the wake phrase

Vosk is general-purpose speech recognition, not a dedicated wake-word
engine built for one specific phrase (which is what the earlier Picovoice
version was, before we switched away from it since it required an
account). That means recognizing the made-up name "Shray" may be a little
less crisp than a real, common word. The code already matches several
likely mishearings ("ready shrey", "ready shre", "red shray", etc. — see
`WAKE_PHRASE_VARIANTS` in `WakeWordService.kt`). If it's not triggering
reliably for you after trying it a few times in a quiet room, let me know
exactly what happens (or doesn't), and we can either add more variant
spellings or switch the trigger phrase to something Vosk recognizes more
consistently.

## A note on the "play a specific song" feature

MX Player doesn't offer a public way for other apps to search its own
library by song name. So instead, Ready Shray searches your phone's own
music/audio files (the same library any music app reads from) for a
matching title, and if found, hands that exact file to MX Player to play.
If no match is found, or you just say "play music" with no song name, it
simply opens MX Player so you can choose yourself.

## Building the APK (same GitHub Actions routine as your other apps)

1. Zip this whole `ReadyShray` folder (it's small - no model file bundled).
2. Create a new GitHub repo, upload the zip as `files.zip`.
3. Add `.github/workflows/build.yml` (provided alongside this project) -
   this version automatically downloads the Vosk model during the build.
4. Push → **Actions** tab → wait for ✅ (this build takes a bit longer than
   your other apps, since it's also downloading a ~40MB model) → download
   from **Artifacts** → extract → install `app-debug.apk`.

This project already includes a fixed debug keystore, so future rebuilds
keep the same signature and install directly over old versions.

## If background listening stops after a while

Go to Settings → Apps → Ready Shray → Battery, and set it to "Unrestricted"
/ "Don't optimize". Some phone brands (Samsung, Xiaomi, etc.) are quite
aggressive about killing background apps to save power, and this is the
one-time fix.

## If the first build fails

This is the first time this project uses the Vosk library, which I
couldn't test-compile myself before handing it to you (I don't have a
live Android build environment). If GitHub Actions shows a red ❌, send me
a screenshot of the failing step exactly like we've done for your other
apps, and I'll fix the code directly from the error message.
