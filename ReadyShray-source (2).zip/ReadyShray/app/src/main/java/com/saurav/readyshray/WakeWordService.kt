package com.saurav.readyshray

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService

/**
 * Runs continuously in the background listening only for the "Ready Shray"
 * wake phrase (fully offline, via Vosk - a free, open-source speech engine
 * that needs no account or API key). When detected, it launches the
 * transparent CommandActivity to capture your actual spoken command.
 *
 * SETUP NEEDED (see README): you must place a Vosk model zip named
 * "vosk-model-small-en.zip" in app/src/main/assets/.
 *
 * Note: unlike a dedicated wake-word engine, Vosk is general speech
 * recognition, so it recognizes the made-up name "Shray" a bit less
 * reliably than a real word. WAKE_PHRASE_VARIANTS below lists common
 * mishearings we match against - if it's not triggering for you, tell me
 * what it heard instead (see the Logcat / on-screen hints) and we can add
 * more variants.
 */
class WakeWordService : Service() {

    private var model: Model? = null
    private var speechService: SpeechService? = null
    private var isPaused = false
    private val channelId = "ready_shray_wake_word_channel"
    private val binder = LocalBinder()

    companion object {
        private val WAKE_PHRASE_VARIANTS = listOf(
            "ready shray", "ready shrey", "ready shre", "ready shy",
            "red shray", "red he shray", "ready shrai", "ready shri"
        )

        fun containsWakePhrase(text: String): Boolean {
            val normalized = text.lowercase().replace(Regex("[^a-z ]"), "").trim()
            return WAKE_PHRASE_VARIANTS.any { normalized.contains(it) }
        }
    }

    inner class LocalBinder : Binder() {
        fun getService(): WakeWordService = this@WakeWordService
        fun getModel(): Model? = model
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        loadModelAndStartListening()
        return START_STICKY
    }

    private fun loadModelAndStartListening() {
        if (model != null) {
            startListening()
            return
        }
        try {
            StorageService.unpack(
                this, "vosk-model-small-en", "model",
                { loadedModel ->
                    model = loadedModel
                    startListening()
                },
                { exception ->
                    // Common cause: vosk-model-small-en.zip missing/invalid in assets
                    showFailureAndStop("Couldn't load speech model: ${exception.message}")
                }
            )
        } catch (e: Exception) {
            showFailureAndStop("Couldn't load speech model: ${e.message}")
        }
    }

    private fun showFailureAndStop(message: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, "Ready Shray: $message", Toast.LENGTH_LONG).show()
        }
        val prefs = getSharedPreferences("ready_shray_prefs", MODE_PRIVATE)
        prefs.edit().putBoolean("enabled", false).apply()
        stopSelf()
    }

    private fun startListening() {
        val currentModel = model ?: return
        try {
            val recognizer = Recognizer(currentModel, 16000.0f)
            speechService = SpeechService(recognizer, 16000.0f)
            speechService?.startListening(wakeWordListener)
            isPaused = false
        } catch (e: Exception) {
            showFailureAndStop("Couldn't start listening: ${e.message}")
        }
    }

    private val wakeWordListener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            checkForWakePhrase(hypothesis)
        }

        override fun onResult(hypothesis: String?) {
            checkForWakePhrase(hypothesis)
        }

        override fun onFinalResult(hypothesis: String?) {
            checkForWakePhrase(hypothesis)
        }

        override fun onError(exception: Exception?) {
            // Try to recover by restarting listening
            startListening()
        }

        override fun onTimeout() {
            // Continuous listening mode - just keep going
        }
    }

    private fun checkForWakePhrase(hypothesisJson: String?) {
        if (hypothesisJson.isNullOrBlank() || isPaused) return
        try {
            val json = JSONObject(hypothesisJson)
            val text = json.optString("partial", "").ifBlank { json.optString("text", "") }
            if (text.isNotBlank() && containsWakePhrase(text)) {
                onWakeWordDetected()
            }
        } catch (e: Exception) {
            // ignore malformed JSON from a partial hypothesis
        }
    }

    private fun onWakeWordDetected() {
        pauseListening()
        val intent = Intent(this, CommandActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    /** Called by CommandActivity while it borrows the microphone for the command. */
    fun pauseListening() {
        isPaused = true
        speechService?.stop()
    }

    /** Called by CommandActivity once it's done, to resume wake-word listening. */
    fun resumeListening() {
        startListening()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        try {
            speechService?.stop()
            speechService?.shutdown()
        } catch (e: Exception) {
            // ignore cleanup errors
        }
        speechService = null
        super.onDestroy()
    }
}
