package com.saurav.readyshray

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/**
 * Runs continuously in the background listening only for the "Ready Shray"
 * wake phrase (fully offline, via Vosk). When detected, it launches the
 * transparent CommandActivity to capture your actual spoken command.
 *
 * The ongoing notification shows the last thing it heard live, so you can
 * check exactly what it's transcribing while you speak.
 */
class WakeWordService : Service() {

    private var model: Model? = null
    private var speechService: SpeechService? = null
    private var isPaused = false
    private val channelId = "ready_shray_wake_word_channel"
    private val binder = LocalBinder()

    companion object {
        private val READY_VARIANTS = listOf("ready", "red", "redi", "reddy", "ready's", "readys")
        private val SHRAY_VARIANTS = listOf(
            "shray", "shrey", "shre", "shri", "shrai", "shry", "shy", "shrayy",
            "city", "citi", "shady", "shirey"
        )

        /**
         * Looks for a "ready"-like word followed within the next couple of
         * words by a "shray"-like word, rather than requiring an exact
         * two-word phrase match - this tolerates small transcription
         * hiccups much better than a fixed phrase list.
         */
        fun containsWakePhrase(text: String): Boolean {
            val words = text.lowercase().replace(Regex("[^a-z ]"), "").trim().split(Regex("\\s+"))
            for (i in words.indices) {
                if (READY_VARIANTS.contains(words[i])) {
                    val upperBound = minOf(i + 2, words.size - 1)
                    for (j in (i + 1)..upperBound) {
                        if (SHRAY_VARIANTS.any { words[j] == it || words[j].startsWith(it.take(3)) }) {
                            return true
                        }
                    }
                }
            }
            return false
        }
    }

    inner class LocalBinder : Binder() {
        fun getService(): WakeWordService = this@WakeWordService
        fun getModel(): Model? = model
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        loadModelAndStartListening()
        return START_STICKY
    }

    private fun loadModelAndStartListening() {
        if (model != null) {
            startListening()
            return
        }
        Thread {
            try {
                val modelDir = File(filesDir, "vosk-model")
                val alreadyExtracted = modelDir.exists() && (modelDir.listFiles()?.isNotEmpty() == true)
                if (!alreadyExtracted) {
                    extractModelFromAssets(modelDir)
                }
                val loadedModel = Model(modelDir.absolutePath)
                model = loadedModel
                Handler(Looper.getMainLooper()).post { startListening() }
            } catch (e: Exception) {
                showFailureAndStop("Couldn't load speech model: ${e.message}")
            }
        }.start()
    }

    private fun extractModelFromAssets(targetDir: File) {
        targetDir.mkdirs()
        assets.open("vosk-model-small-en.zip").use { input ->
            ZipInputStream(BufferedInputStream(input)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val outFile = File(targetDir, entry.name)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { fos -> zis.copyTo(fos) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
    }

    private fun showFailureAndStop(message: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, "Ready Shray: $message", Toast.LENGTH_LONG).show()
        }
        val prefs = getSharedPreferences("ready_shray_prefs", MODE_PRIVATE)
        prefs.edit().putBoolean("enabled", false).apply()
        stopSelf()
    }

    private fun startListening() {
        val currentModel = model ?: return
        try {
            // FIX: release any previous session before creating a new one,
            // to avoid leaking native resources every time we pause/resume
            // around a command (this happens on every single wake-word
            // trigger, so over a session this adds up).
            speechService?.let {
                try { it.stop() } catch (e: Exception) { /* already stopped */ }
                try { it.shutdown() } catch (e: Exception) { /* ignore */ }
            }

            val recognizer = Recognizer(currentModel, 16000.0f)
            speechService = SpeechService(recognizer, 16000.0f)
            speechService?.startListening(wakeWordListener)
            isPaused = false
        } catch (e: Exception) {
            showFailureAndStop("Couldn't start listening: ${e.message}")
        }
    }

    private val wakeWordListener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            checkForWakePhrase(hypothesis)
        }

        override fun onResult(hypothesis: String?) {
            checkForWakePhrase(hypothesis)
        }

        override fun onFinalResult(hypothesis: String?) {
            checkForWakePhrase(hypothesis)
        }

        override fun onError(exception: Exception?) {
            startListening()
        }

        override fun onTimeout() {
            // Continuous listening mode - just keep going
        }
    }

    private fun checkForWakePhrase(hypothesisJson: String?) {
        if (hypothesisJson.isNullOrBlank() || isPaused) return
        try {
            val json = JSONObject(hypothesisJson)
            val text = json.optString("partial", "").ifBlank { json.optString("text", "") }
            if (text.isNotBlank()) {
                updateNotificationWithHeardText(text)
                if (containsWakePhrase(text)) {
                    onWakeWordDetected()
                }
            }
        } catch (e: Exception) {
            // ignore malformed JSON from a partial hypothesis
        }
    }

    private fun updateNotificationWithHeardText(text: String) {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        val notification = Notification.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText("Last heard: \"$text\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        manager.notify(1, notification)
    }

    private fun onWakeWordDetected() {
        pauseListening()
        val intent = Intent(this, CommandActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    /** Called by CommandActivity while it borrows the microphone for the command. */
    fun pauseListening() {
        // FIX: guard against being called twice in a row (this used to
        // happen once here, then again from CommandActivity right after) -
        // calling stop() on an already-stopped session is unnecessary and
        // was a latent risk depending on the library's internal state.
        if (isPaused) return
        isPaused = true
        speechService?.stop()
    }

    /** Called by CommandActivity once it's done, to resume wake-word listening. */
    fun resumeListening() {
        startListening()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        try {
            speechService?.stop()
            speechService?.shutdown()
        } catch (e: Exception) {
            // ignore cleanup errors
        }
        speechService = null
        super.onDestroy()
    }
}
