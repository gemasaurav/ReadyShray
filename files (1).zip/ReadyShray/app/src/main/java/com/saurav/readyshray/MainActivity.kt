package com.saurav.readyshray

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var btnToggle: Button
    private lateinit var tvStatus: TextView

    private val permissionRequestCode = 200

    private val requiredPermissions: Array<String>
        get() {
            val base = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                base.add(Manifest.permission.POST_NOTIFICATIONS)
                base.add(Manifest.permission.READ_MEDIA_AUDIO)
            } else {
                base.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            return base.toTypedArray()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnToggle = findViewById(R.id.btnToggle)
        tvStatus = findViewById(R.id.tvStatus)

        updateStatusUI()

        btnToggle.setOnClickListener {
            if (isEnabled()) {
                disableAssistant()
            } else {
                requestPermissionsThenEnable()
            }
        }
    }

    private fun isEnabled(): Boolean {
        val prefs = getSharedPreferences("ready_shray_prefs", MODE_PRIVATE)
        return prefs.getBoolean("enabled", false)
    }

    private fun setEnabled(enabled: Boolean) {
        val prefs = getSharedPreferences("ready_shray_prefs", MODE_PRIVATE)
        prefs.edit().putBoolean("enabled", enabled).apply()
    }

    private fun requestPermissionsThenEnable() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), permissionRequestCode)
        } else {
            startAssistant()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            val allGranted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (allGranted) {
                startAssistant()
            } else {
                Toast.makeText(this, "Ready Shray needs these permissions to work", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startAssistant() {
        setEnabled(true)
        val serviceIntent = Intent(this, WakeWordService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        updateStatusUI()
    }

    private fun disableAssistant() {
        setEnabled(false)
        stopService(Intent(this, WakeWordService::class.java))
        updateStatusUI()
    }

    private fun updateStatusUI() {
        if (isEnabled()) {
            tvStatus.text = getString(R.string.status_on)
            btnToggle.text = getString(R.string.disable_button)
        } else {
            tvStatus.text = getString(R.string.status_off)
            btnToggle.text = getString(R.string.enable_button)
        }
    }
}
