package com.saurav.readyshray

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

/**
 * Appears the instant the wake word is detected. Borrows the microphone
 * from WakeWordService (which pauses its own listening while this is open),
 * captures your actual spoken command ("call Mom" or "play <song>"), shows
 * what it understood, performs the action via CommandProcessor, hands the
 * microphone back to WakeWordService, then closes itself.
 */
class CommandActivity : AppCompatActivity() {

    private lateinit var tvPrompt: TextView
    private lateinit var tvRecognized: TextView
    private lateinit var progressBar: ProgressBar

    private var wakeWordService: WakeWordService? = null
    private var isBound = false
    private var commandSpeechService: SpeechService? = null
    private val timeoutHandler = Handler(Looper.getMainLooper())
    private var finished = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? WakeWordService.LocalBinder ?: return
            wakeWordService = binder.getService()
            wakeWordService?.pauseListening()
            startListeningForCommand(binder.getModel())
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            wakeWordService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_command)

        tvPrompt = findViewById(R.id.tvPrompt)
        tvRecognized = findViewById(R.id.tvRecognized)
        progressBar = findViewById(R.id.progressBar)

        val intent = Intent(this, WakeWordService::class.java)
        isBound = bindService(intent, connection, Context.BIND_AUTO_CREATE)

        // Safety timeout in case nothing is recognized at all
        timeoutHandler.postDelayed({ finishAndResume("Didn't catch that") }, 7000)
    }

    private fun startListeningForCommand(model: org.vosk.Model?) {
        if (model == null) {
            finishAndResume("Speech model not ready")
            return
        }
        try {
            val recognizer = Recognizer(model, 16000.0f)
            commandSpeechService = SpeechService(recognizer, 16000.0f)
            commandSpeechService?.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String?) {}

                override fun onResult(hypothesis: String?) {
                    val text = extractText(hypothesis)
                    if (text.isNotBlank()) {
                        handleRecognizedCommand(text)
                    }
                }

                override fun onFinalResult(hypothesis: String?) {
                    val text = extractText(hypothesis)
                    if (text.isNotBlank()) {
                        handleRecognizedCommand(text)
                    } else {
                        finishAndResume("Didn't catch that")
                    }
                }

                override fun onError(exception: Exception?) {
                    finishAndResume("Didn't catch that")
                }

                override fun onTimeout() {
                    finishAndResume("Didn't catch that")
                }
            })
        } catch (e: Exception) {
            finishAndResume("Couldn't start listening")
        }
    }

    private fun extractText(hypothesisJson: String?): String {
        if (hypothesisJson.isNullOrBlank()) return ""
        return try {
            JSONObject(hypothesisJson).optString("text", "")
        } catch (e: Exception) {
            ""
        }
    }

    private fun handleRecognizedCommand(text: String) {
        if (finished) return
        tvRecognized.text = "\"$text\""
        progressBar.visibility = View.VISIBLE
        val resultMessage = CommandProcessor.process(applicationContext, text)
        tvPrompt.text = resultMessage
        finishAndResume(delayMs = 1200)
    }

    private fun finishAndResume(message: String? = null, delayMs: Long = 1800) {
        if (finished) return
        finished = true
        timeoutHandler.removeCallbacksAndMessages(null)
        if (message != null) {
            tvRecognized.text = message
        }
        try {
            commandSpeechService?.stop()
            commandSpeechService?.shutdown()
        } catch (e: Exception) {
            // ignore cleanup errors
        }
        tvRecognized.postDelayed({
            wakeWordService?.resumeListening()
            if (isBound) unbindService(connection)
            finish()
        }, delayMs)
    }

    override fun onDestroy() {
        try {
            commandSpeechService?.stop()
            commandSpeechService?.shutdown()
        } catch (e: Exception) {
            // ignore
        }
        super.onDestroy()
    }
}
