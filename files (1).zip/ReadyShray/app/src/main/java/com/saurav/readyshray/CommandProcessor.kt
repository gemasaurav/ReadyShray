package com.saurav.readyshray

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore

/**
 * Takes whatever text was recognized after the wake word and figures out
 * which action to perform:
 * 1. Call/dial a contact by name, OR dial a raw phone number directly
 * 2. Search Google for something
 * 3. Play music through MX Player (either a specific song by name, or just
 *    open MX Player so you can pick)
 */
object CommandProcessor {

    // The two common MX Player package names (Free / Pro editions)
    private val mxPlayerPackages = listOf(
        "com.mxtech.videoplayer.ad",
        "com.mxtech.videoplayer.pro"
    )

    private val digitWords = mapOf(
        "zero" to "0", "oh" to "0", "one" to "1", "two" to "2", "to" to "2", "too" to "2",
        "three" to "3", "four" to "4", "for" to "4", "five" to "5", "six" to "6",
        "seven" to "7", "eight" to "8", "ate" to "8", "nine" to "9"
    )

    fun process(context: Context, spokenText: String): String {
        val text = spokenText.lowercase().trim()

        return when {
            text.startsWith("call ") -> handleCall(context, text.removePrefix("call ").trim())
            text.startsWith("dial ") -> handleCall(context, text.removePrefix("dial ").trim())

            text.startsWith("search ") -> handleSearch(context, text.removePrefix("search ").trim())
            text.startsWith("google ") -> handleSearch(context, text.removePrefix("google ").trim())
            text.contains("search for ") -> handleSearch(context, text.substringAfter("search for ").trim())

            text.contains("play") -> handlePlayMusic(context, text)

            else -> "Didn't understand. Try \"call <name or number>\", \"search <something>\", or \"play <song>\""
        }
    }

    // ---------- Calling ----------

    private fun handleCall(context: Context, spoken: String): String {
        if (spoken.isBlank()) return "Didn't catch who or what number to call"

        // First, check if this looks like a spoken phone number (either digits
        // typed as numerals, or spoken digit-by-digit as words like "nine eight seven").
        val rawNumber = extractPhoneNumber(spoken)
        if (rawNumber != null) {
            return dialNumber(context, rawNumber, rawNumber)
        }

        // Otherwise, treat it as a contact name.
        val phoneNumber = lookupContactNumber(context, spoken)
        if (phoneNumber == null) {
            return "Couldn't find a contact named \"$spoken\""
        }
        return dialNumber(context, phoneNumber, spoken)
    }

    /**
     * Tries to read [spoken] as a phone number - either already-numeral text
     * (e.g. "9876543210") or digits spoken one-by-one (e.g. "nine eight seven
     * six five four three two one zero"), or a mix of both. Returns null if
     * it doesn't look like a number at all (too few digits found), so it
     * falls through to contact-name lookup instead.
     */
    private fun extractPhoneNumber(spoken: String): String? {
        val tokens = spoken.split(Regex("[\\s-]+")).filter { it.isNotBlank() }
        val digitsBuilder = StringBuilder()

        for (token in tokens) {
            when {
                token == "plus" -> digitsBuilder.append("+")
                token.all { it.isDigit() } -> digitsBuilder.append(token)
                digitWords.containsKey(token) -> digitsBuilder.append(digitWords[token])
                else -> return null // a non-numeric word appeared - this is a name, not a number
            }
        }

        val digitsOnly = digitsBuilder.toString().filter { it.isDigit() }
        // Require a realistic minimum length for a phone number
        return if (digitsOnly.length >= 6) digitsBuilder.toString() else null
    }

    private fun dialNumber(context: Context, phoneNumber: String, label: String): String {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        return try {
            context.startActivity(intent)
            "Calling $label"
        } catch (e: SecurityException) {
            "Call permission not granted"
        }
    }

    private fun lookupContactNumber(context: Context, name: String): String? {
        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return it.getString(numberIndex)
            }
        }
        return null
    }

    // ---------- Google search ----------

    private fun handleSearch(context: Context, query: String): String {
        if (query.isBlank()) return "Didn't catch what to search for"
        val encodedQuery = Uri.encode(query)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encodedQuery"))
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        return try {
            context.startActivity(intent)
            "Searching for \"$query\""
        } catch (e: Exception) {
            "Couldn't open a browser to search"
        }
    }

    // ---------- Playing music via MX Player ----------

    private fun handlePlayMusic(context: Context, text: String): String {
        // Strip filler words to isolate a possible song name, e.g.
        // "play music" -> "", "play kesariya in mx player" -> "kesariya"
        var query = text
            .replace("play", "")
            .replace("music", "")
            .replace("song", "")
            .replace("in mx player", "")
            .replace("on mx player", "")
            .replace("mx player", "")
            .trim()

        val installedMxPackage = mxPlayerPackages.firstOrNull { isPackageInstalled(context, it) }
        if (installedMxPackage == null) {
            return "MX Player isn't installed on this phone"
        }

        if (query.isBlank()) {
            // No specific song named - just open MX Player so the user can pick
            return openAppByPackage(context, installedMxPackage, "Opening MX Player")
        }

        val songUri = findAudioUriByTitle(context, query)
        if (songUri == null) {
            // Couldn't find that specific song - fall back to just opening MX Player
            openAppByPackage(context, installedMxPackage, "")
            return "Couldn't find \"$query\" - opened MX Player instead"
        }

        val playIntent = Intent(Intent.ACTION_VIEW)
        playIntent.setDataAndType(songUri, "audio/*")
        playIntent.setPackage(installedMxPackage)
        playIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

        return try {
            context.startActivity(playIntent)
            "Playing \"$query\" in MX Player"
        } catch (e: Exception) {
            "Found \"$query\" but MX Player couldn't play it"
        }
    }

    private fun findAudioUriByTitle(context: Context, query: String): Uri? {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE)
        val selection = "${MediaStore.Audio.Media.TITLE} LIKE ?"
        val selectionArgs = arrayOf("%$query%")

        context.contentResolver.query(collection, projection, selection, selectionArgs, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val id = cursor.getLong(idIndex)
                return Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())
            }
        }
        return null
    }

    private fun isPackageInstalled(context: Context, packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun openAppByPackage(context: Context, packageName: String, resultMessage: String): String {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(launchIntent)
            resultMessage
        } else {
            "Couldn't open MX Player"
        }
    }
}
